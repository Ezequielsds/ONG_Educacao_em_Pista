// Este arquivo é usado somente na página Contato.
const formulario = document.getElementById("formulario-contato");
const nome = document.getElementById("nome");
const email = document.getElementById("email");
const assunto = document.getElementById("assunto");
const mensagem = document.getElementById("mensagem");
const retorno = document.getElementById("retorno-formulario");

function validarFormulario(evento) {
  // Evita que o navegador envie os dados e recarregue a página.
  evento.preventDefault();

  // value lê o campo. trim() remove espaços do começo e do fim.
  const textoNome = nome.value.trim();
  const textoEmail = email.value.trim();
  const textoAssunto = assunto.value.trim();
  const textoMensagem = mensagem.value.trim();
  email.value = textoEmail;

  // let permite mudar o conteúdo desta variável durante a validação.
  let erro = "";

  // Conferimos um campo por vez. length conta os caracteres.
  if (textoNome.length < 3) {
    erro = "O nome precisa ter pelo menos 3 caracteres.";
    nome.focus();
  } else if (textoEmail === "" || !email.checkValidity()) {
    // checkValidity usa a regra do input type=email.
    erro = "Digite um e-mail válido.";
    email.focus();
  } else if (textoAssunto === "") {
    erro = "Preencha o assunto.";
    assunto.focus();
  } else if (textoMensagem.length < 10) {
    erro = "A mensagem precisa ter pelo menos 10 caracteres.";
    mensagem.focus();
  }

  // textContent escreve a resposta dentro do parágrafo do HTML.
  if (erro !== "") {
    retorno.textContent = erro;
    retorno.className = "retorno erro";
  } else {
    retorno.textContent = "Mensagem validada! É uma simulação: nada foi enviado ou guardado.";
    retorno.className = "retorno sucesso";
    formulario.reset();
  }
}

// submit acontece ao acionar o envio do formulário, inclusive pelo teclado.
formulario.addEventListener("submit", validarFormulario);
