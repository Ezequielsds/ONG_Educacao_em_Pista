// Este arquivo é usado somente na página inicial.
// const guarda a referência de um elemento que já existe no HTML.
const botao = document.getElementById("botao-participar");
const painel = document.getElementById("painel-participar");

// Esta função alterna entre os dois estados do painel.
function mostrarOuEsconder() {
  if (painel.hidden) {
    painel.hidden = false;
    botao.textContent = "Fechar orientações";
    botao.setAttribute("aria-expanded", "true");
  } else {
    painel.hidden = true;
    botao.textContent = "Como posso participar?";
    botao.setAttribute("aria-expanded", "false");
  }
}

// O navegador chama a função quando a pessoa clica no botão.
botao.addEventListener("click", mostrarOuEsconder);
